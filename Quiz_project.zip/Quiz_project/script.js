const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || {};
const userScores = {};
const quizQuestions = [
    {
        question: "What is the capital of France?",
        options: ["Paris", "Berlin", "London"],
        correctAnswer: "Paris",
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Mars", "Venus", "Jupiter"],
        correctAnswer: "Mars",
    },
    {
        question: "What is the largest mammal in the world?",
        options: ["Elephant", "Blue Whale", "Giraffe"],
        correctAnswer: "Blue Whale",
    },
];

let currentQuestion = 0;
let score = 0;
let username = "";
let usersCompletedQuiz = [];

// DOM elements
const loginContainer = document.getElementById("login-container");
const registerContainer = document.getElementById("register-container");
const quizContainer = document.getElementById("quiz-container");
const resultContainer = document.getElementById("result-container");
const questionElement = document.getElementById("question");
const optionsElement = document.getElementById("options");
const scoreElement = document.getElementById("score");

// Login functionality
document.getElementById("login").addEventListener("click", () => {
    const enteredUsername = document.getElementById("username").value;
    const enteredPassword = document.getElementById("password").value;

    if (registeredUsers[enteredUsername] === enteredPassword) {
        username = enteredUsername;
        loginContainer.style.display = "none";
        registerContainer.style.display = "none";
        quizContainer.style.display = "block";
        showNextQuestion(); // Call the function to display the first question
    } else {
        alert("Login failed. Please check your username and password.");
    }
});

// Registration functionality
document.getElementById("register").addEventListener("click", () => {
    const newUsername = document.getElementById("new-username").value;
    const newPassword = document.getElementById("new-password").value;

    if (newUsername && newPassword) {
        registeredUsers[newUsername] = newPassword;
        // Save updated user data to localStorage
        localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
        alert("Registration successful. You can now log in.");
    } else {
        alert("Please enter a username and password.");
    }
});

// Quiz functionality
document.getElementById("next").addEventListener("click", () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        if (selectedOption.value === quizQuestions[currentQuestion].correctAnswer) {
            score++;
        }
        currentQuestion++;
        if (currentQuestion < quizQuestions.length) {
            showNextQuestion();
        } else {
            // Instead of showing the leaderboard, show the final score
            showResult();
        }
    }
});




// Refresh the quiz
document.getElementById("refresh").addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    showNextQuestion();
    resultContainer.style.display = "none";
    quizContainer.style.display = "block";
});



function saveUserScore(username, score) {
    const completedUsersQuiz = JSON.parse(localStorage.getItem('completedUsersQuiz')) || {};
    completedUsersQuiz[username] = score;
    localStorage.setItem('completedUsersQuiz', JSON.stringify(completedUsersQuiz));
}

// Show all user scores functionality
document.getElementById("show-scores").addEventListener("click", () => {
    const completedUsersQuiz = JSON.parse(localStorage.getItem('completedUsersQuiz'));
    const userScoresElement = document.getElementById("user-scores");

    if (completedUsersQuiz) {
        userScoresElement.style.display = "block";
        userScoresElement.innerHTML = "<h3>User Scores</h3>";

        for (const username in completedUsersQuiz) {
            userScoresElement.innerHTML += `${username}: ${completedUsersQuiz[username]}<br>`;
        }
    } else {
        userScoresElement.style.display = "block";
        userScoresElement.innerHTML = "No user scores available.";
    }
});



// Show result functionality
// function showResult() {
//     quizContainer.style.display = "none";
//     resultContainer.style.display = "block"; // Corrected line
//     scoreElement.textContent = `${username}, your score is ${score}/${quizQuestions.length}.`;
// }

function showResult() {
    quizContainer.style.display = "none";
    resultContainer.style.display = "block";
    scoreElement.textContent = `${username}, your score is ${score}/${quizQuestions.length}.`;
    saveUserScore(username, score); // Save the user's score
}




// Restart quiz button
document.getElementById("restart-quiz").addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    showNextQuestion();
    resultContainer.style.display = "none";
    quizContainer.style.display = "block";
});

// Back to login button
document.getElementById("back-to-login").addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    username = "";
    loginContainer.style.display = "block";
    registerContainer.style.display = "block";
    quizContainer.style.display = "none";
    resultContainer.style.display = "none";
});

// Function to display the current question
function showNextQuestion() {
    questionElement.textContent = quizQuestions[currentQuestion].question;
    optionsElement.innerHTML = "";

    quizQuestions[currentQuestion].options.forEach((option) => {
        const radioInput = document.createElement("input");
        radioInput.type = "radio";
        radioInput.name = "option";
        radioInput.value = option;
        optionsElement.appendChild(radioInput);
        optionsElement.appendChild(document.createTextNode(option));
        optionsElement.appendChild(document.createElement("br"));
    });
}


// Initial display
loginContainer.style.display = "block";
registerContainer.style.display = "block";
quizContainer.style.display = "none";
resultContainer.style.display = "none";