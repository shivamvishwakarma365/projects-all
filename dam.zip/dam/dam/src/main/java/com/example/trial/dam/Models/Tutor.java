package com.example.trial.dam.Models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "tutors")
public class Tutor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tutor_id")
    private Long tutorId;

    @Column(name = "tutor_name")
    private String tutorName;

    @Column(name = "tutor_email", unique = true)
    private String tutorEmail;

    @Column(name = "tutor_expertise")
    private String tutorExpertise;

    @Column(name = "tutor_availability")
    private String tutorAvailability;

    // Define the one-to-many relationship with sessions
    @OneToMany(mappedBy = "tutor")
    private List<Session> sessions;

    // Define the one-to-many relationship with ratings
    @OneToMany(mappedBy = "tutor")
    private List<Ratings> ratings;

    // Constructors, getters, and setters

    public Tutor() {
    }

    public Tutor(String tutorName, String tutorEmail, String tutorExpertise, String tutorAvailability) {
        this.tutorName = tutorName;
        this.tutorEmail = tutorEmail;
        this.tutorExpertise = tutorExpertise;
        this.tutorAvailability = tutorAvailability;
    }

    // Getter and Setter methods for fields

    public Long getTutorId() {
        return tutorId;
    }

    public void setTutorId(Long tutorId) {
        this.tutorId = tutorId;
    }

    public String getTutorName() {
        return tutorName;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }

    public String getTutorEmail() {
        return tutorEmail;
    }

    public void setTutorEmail(String tutorEmail) {
        this.tutorEmail = tutorEmail;
    }

    public String getTutorExpertise() {
        return tutorExpertise;
    }

    public void setTutorExpertise(String tutorExpertise) {
        this.tutorExpertise = tutorExpertise;
    }

    public String getTutorAvailability() {
        return tutorAvailability;
    }

    public void setTutorAvailability(String tutorAvailability) {
        this.tutorAvailability = tutorAvailability;
    }

    public List<Session> getSessions() {
        return sessions;
    }

    public void setSessions(List<Session> sessions) {
        this.sessions = sessions;
    }

    public List<Ratings> getRatings() {
        return ratings;
    }

    public void setRatings(List<Ratings> ratings) {
        this.ratings = ratings;
    }

}
