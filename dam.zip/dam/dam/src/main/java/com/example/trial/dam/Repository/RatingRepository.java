package com.example.trial.dam.Repository;


import com.example.trial.dam.Models.Ratings;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface RatingRepository extends JpaRepository<Ratings, Long> {


}

