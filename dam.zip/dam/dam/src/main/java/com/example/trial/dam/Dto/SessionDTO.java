package com.example.trial.dam.Dto;

import com.example.trial.dam.Models.Student;
import com.example.trial.dam.Models.Tutor;

import java.time.LocalDateTime;

public class SessionDTO {
    private Long sessionId;
    private Tutor tutor;
    private Student student;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String subject;
    private String status;

    // Constructors, getters, and setters

    public SessionDTO() {
    }

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
