package com.example.trial.dam.Dto;

import com.example.trial.dam.Models.*;

public class RatingDtoLayer {
    private Session sessions;

    private Tutor tutor;

    private Student student;

    public long ratingId;
    public int ratingPoint;
    public String review;

    public RatingDtoLayer() {
    }

    public RatingDtoLayer(Session sessions, Tutor tutor, Student student, long ratingId, int ratingPoint, String review) {
        this.sessions = sessions;
        this.tutor = tutor;
        this.student = student;
        this.ratingId = ratingId;
        this.ratingPoint = ratingPoint;
        this.review = review;
    }

    public Session getSessions() {
        return sessions;
    }

    public void setSessions(Session sessions) {
        this.sessions = sessions;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public long getRatingId() {
        return ratingId;
    }

    public void setRatingId(long ratingId) {
        this.ratingId = ratingId;
    }

    public int getRatingPoint() {
        return ratingPoint;
    }

    public void setRatingPoint(int ratingPoint) {
        this.ratingPoint = ratingPoint;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
