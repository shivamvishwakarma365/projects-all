package com.example.trial.dam.Controllers;

import com.example.trial.dam.Dto.TutorDTO;
import com.example.trial.dam.Models.Ratings;
import com.example.trial.dam.Models.Tutor;
import com.example.trial.dam.Services.TutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tutor")
public class TutorController {
    @Autowired
    private TutorService tutorService;

    // Create a new tutor
    @PostMapping("/create")
    public ResponseEntity<Object> createTutor(@RequestBody TutorDTO tutorDTO) {
        try {
            Tutor createdTutor = tutorService.createTutor(tutorDTO);
            if (createdTutor != null) {
                return ResponseEntity.status(HttpStatus.CREATED).body(createdTutor);
            } else {
                return ResponseEntity.badRequest().body("Unable to create tutor."); // Handle error case
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while creating the tutor.");
        }
    }


    @GetMapping("/{tutorId}")
    public ResponseEntity<Tutor> getTutorById(@PathVariable Long tutorId) {
        Optional<Tutor> tutor = tutorService.getTutorById(tutorId);
        return tutor.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{tutorId}")
    public ResponseEntity<Tutor> updateTutor(@PathVariable Long tutorId, @RequestBody TutorDTO updatedTutorDTO) {
        Tutor updated = tutorService.updateTutor(tutorId, updatedTutorDTO);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build(); // Handle not found case
        }
    }

    @DeleteMapping("/{tutorId}")
    public ResponseEntity<Void> deleteTutor(@PathVariable Long tutorId) {
        tutorService.deleteTutor(tutorId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    public ResponseEntity<List<Tutor>> getAllTutors() {
        List<Tutor> tutors = tutorService.getAllTutors();
        return ResponseEntity.ok(tutors);
    }

    @GetMapping("/by-expertise")
    public ResponseEntity<List<Tutor>> getTutorsByExpertise(@RequestParam String expertise) {
        List<Tutor> tutors = tutorService.getTutorsByTutorExpertise(expertise);
        return ResponseEntity.ok(tutors);
    }


}
