package com.example.trial.dam.Models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name = "ratings")
public class Ratings {

    @ManyToOne
    @JoinColumn(name = "tutor_id")
    @JsonIgnoreProperties("ratings")
    private Tutor tutor;

    @ManyToOne
    @JoinColumn(name = "student_id")
    @JsonIgnoreProperties("ratings")
    private Student student;

    @ManyToOne(fetch = FetchType.EAGER) //Throws error
    @JoinColumn(name = "session_id")
    @JsonIgnoreProperties("ratings")
    private Session sessions;



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rating_id")
    private Long ratingId;

    @Column(name = "rating_point")
    private int ratingPoint;

    @Column(name = "review")
    private String review;

    public Ratings() {
    }

    public Ratings(Tutor tutor, Student student, Session sessions, Long ratingId, int ratingPoint, String review) {
        this.tutor = tutor;
        this.student = student;
        this.sessions = sessions;
        this.ratingId = ratingId;
        this.ratingPoint = ratingPoint;
        this.review = review;
    }


    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Session getSessions() {
        return sessions;
    }

    public void setSessions(Session sessions) {
        this.sessions = sessions;
    }

    public Long getRatingId() {
        return ratingId;
    }

    public void setRatingId(Long ratingId) {
        this.ratingId = ratingId;
    }

    public int getRatingPoint() {
        return ratingPoint;
    }

    public void setRatingPoint(int ratingPoint) {
        this.ratingPoint = ratingPoint;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
