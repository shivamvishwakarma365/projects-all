package com.example.trial.dam.Services;

import com.example.trial.dam.Dto.StudentDTO;
import com.example.trial.dam.Models.Student;
import com.example.trial.dam.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<StudentDTO> getAllStudents() {
        List<Student> students = studentRepository.findAll();
        return students.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

//        return students.stream()
//                .map(student -> convertToDTO(student))
//                .collect(Collectors.toList());

    }


    public StudentDTO getStudentById(long studentId) {
        Optional<Student> studentOptional = studentRepository.findById(studentId);
        return studentOptional.map(this::convertToDTO)
                .orElse(null);

//        Optional<Student> studentOptional = studentRepository.findById(studentId);
//        Student student = null;
//        if (studentOptional.isPresent()) {
//            student = studentOptional.get();
//        }

//        public StudentDTO getStudentById(long studentId) {
//            Student student = studentRepository.findById(studentId).orElse(null);
//            if (student != null) {
//                return convertToDTO(student);
//            } else {
//                return null; // Return null when student is not found
//            }
//        }


    }
    public StudentDTO createStudent(StudentDTO studentDTO) {
        Student student = convertToEntity(studentDTO);
        Student savedStudent = studentRepository.save(student);
        return convertToDTO(savedStudent);
    }

    public StudentDTO updateStudent(long studentId, StudentDTO studentDTO) {
        Optional<Student> studentOptional = studentRepository.findById(studentId);
        if (studentOptional.isPresent()) {
            Student student = studentOptional.get();
            student.setStudentName(studentDTO.getStudentName());
            student.setStudentEmail(studentDTO.getStudentEmail());
            Student updatedStudent = studentRepository.save(student);
            return convertToDTO(updatedStudent);
        }
        return null;
    }

    public boolean deleteStudent(long studentId) {
        Optional<Student> studentOptional = studentRepository.findById(studentId);
        if (studentOptional.isPresent()) {
            studentRepository.deleteById(studentId);
            return true;
        }
        return false;
    }

    private StudentDTO convertToDTO(Student student) {
        StudentDTO studentDTO = new StudentDTO();
        studentDTO.setStudentId(student.getStudentId());
        studentDTO.setStudentName(student.getStudentName());
        studentDTO.setStudentEmail(student.getStudentEmail());
        return studentDTO;
    }

    private Student convertToEntity(StudentDTO studentDTO) {
        Student student = new Student();
        student.setStudentName(studentDTO.getStudentName());
        student.setStudentEmail(studentDTO.getStudentEmail());
        return student;
    }
}
