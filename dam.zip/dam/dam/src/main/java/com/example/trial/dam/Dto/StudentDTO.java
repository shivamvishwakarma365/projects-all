package com.example.trial.dam.Dto;

public class StudentDTO {
    private long studentId;
    private String studentName;
    private String studentEmail;

    // Constructors, getters, and setters
    // ...
    public StudentDTO() {
    }

    public StudentDTO(long studentId, String studentName, String studentEmail) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
    }

    // Getter and Setter methods for fields

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }
}
