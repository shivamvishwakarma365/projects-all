package com.example.trial.dam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DamApplicationTests {

	@Test
	void contextLoads() {
	}

}
